require('shelljs/global');
cp('-R', 'assets/', 'dist/assets');
